export const DRAW_X = 'DRAW_X'
export const DRAW_O = 'DRAW_O'
export const RESET = 'RESET'

export const PLAYER_X = 'PLAYER_X'
export const PLAYER_O = 'PLAYER_X'
export const TURN = 'TURN'
export const RESET_PLAYERS = 'RESET_PLAYERS'

export const X_WINS = 'X_WINS'
export const O_WINS = 'O_WINS'
export const TIE = 'TIE'
export const RESET_RESULTS = 'RESET_RESULTS'



export const PLAYER_1 = 'PLAYER_1'
export const PLAYER_2 = 'PLAYER_2'
export const ERROR_MSG = 'ERROR_MSG'

